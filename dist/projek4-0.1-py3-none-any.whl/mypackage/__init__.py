from module1 import welcome_page

sapaan = welcome_page("selamat datang di permainan kami")