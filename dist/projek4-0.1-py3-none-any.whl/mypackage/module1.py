def welcome_page(title):
    isian = "="*(len(title)+6)
    print(f"{isian}")
    print(f"==={title}===")
    print(f"{isian}")
