# setup.py
from setuptools import setup, find_packages
from os import path

setup(
    name='mypackage',  # Nama package
    version='0.1',  # Versi
    packages=find_packages(),  # Secara otomatis menemukan paket
    install_requires=[
        # Daftar dependencies
    ],
    description='Deskripsi singkat package Anda',
    author='Nama Anda',
    author_email='irafitrinovanda@gmail.com',
    url='https://github.com/Anugrahfitri-code/mypackage',  # URL repositori atau dokumentasi
    license='MIT',  # Lisensi package
    long_description=open('README.md').read(),  # Deskripsi lengkap (dari README.md)
    long_description_content_type='text/markdown',
)
